# fastText AG News Patch Proof Bundle

- Stage: `p4_fasttext_patch_proof_bundle`
- Review status: `approved_with_limitations`
- Baseline P@1: `0.914`
- Patch P@1: `0.916`
- Delta: `0.002`
- Improved: `True`
- Artifact count: `10`
- Claim boundary: local controlled fastText patch-loop proof only; not a leaderboard score, full-paper reproduction, or arbitrary automatic improvement
- `official_scores_claimed=false`

## Artifacts

- `improvement_report` -> `artifacts/improvement-report.json` sha256 `ebbaf27dc59fd1fa897803ad5b945b714563922fa9c0ed9598644c3be5ae1743`
- `baseline_report` -> `artifacts/baseline-report.json` sha256 `887e00d2a026e93d062cc8adc6d90e611d4f56f822145d4dddfeb97007a02409`
- `dataset_provenance` -> `artifacts/dataset-provenance.json` sha256 `0fc5d516cf28bf1479537001318dd398fecfa49f047eda4159458ca2853d3a8d`
- `runtime_probe` -> `artifacts/fasttext-runtime-probe.json` sha256 `9d68209ba26a0059af1c566b80027bd487b0ef50c7ba25ea3004a603a260ec47`
- `patch_proposal` -> `artifacts/patch-proposal.json` sha256 `9b466b044d2cef36c48faf49fa4744777cfae1023fc9bee3657a48799f9fcfdf`
- `patch_diff` -> `artifacts/patch-diff.patch` sha256 `25cf738c39ceaa31c282a5afa17904c19623a8e897f7ea03fb49b9f197d1ec66`
- `train_log` -> `artifacts/fasttext-patch-train.log` sha256 `39540e726f04d0eb941d2719287b944200cebd7b66ca31e1a73697ae4e156236`
- `test_log` -> `artifacts/fasttext-patch-test.log` sha256 `95b22b0361c22cce166de952c47ada061d8e3a6461a3cdbcc093f7acb125ff88`
- `client_handoff` -> `artifacts/client-handoff.json` sha256 `ff4f7e5381acc02d9073cf0ef296b92fc9fe8de4e91c6b26907db1943752e297`
- `human_review_report` -> `human-review-report.json` sha256 `2f39e347fbd79ee81ac3fb14c3116ec3649a788710e0cebab24c7a3449dc80ad`
