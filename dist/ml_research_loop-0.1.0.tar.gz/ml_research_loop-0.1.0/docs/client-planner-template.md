# Codex/Claude 客户端 Planner 模板

## 职责

客户端 planner 使用 Codex/Claude 的大模型能力做判断，MCP 服务只负责执行实验、读取论文、返回状态和结果。默认不要让服务端隐式调用 LLM；只有需要无人值守自动实验时，才显式调用 `run_ai_autoresearch`。

目标架构见 `docs/product/target-architecture-cn.md`。客户端 planner 可以使用 Research Memory Layer 提供的历史经验，但 memory suggestion 只能作为候选上下文；真正的代码、超参、训练、归档和 benchmark 动作仍必须走 MCP 的受控工具。

## 每轮输入

每次调用 `review_research_results` 后，优先读取：

- `experiment_state.best_result`
- `experiment_state.summary`
- `experiment_state.recent_experiments`
- `experiment_state.failure_summary`
- `experiment_state.failure_diagnostics`
- `experiment_state.metric_stop_policy`
- `experiment_state.research_evidence_gate`
- `experiment_state.planner_actions`
- `experiment_state.code_change_plan.next_experiment_plan`
- `experiment_state.code_change_plan.next_experiment_plan.proposed_task_patch`
- `experiment_state.code_change_plan.next_experiment_plan.dry_run_validation`
- `experiment_state.current_code.search_region`
- `experiment_state.next_round.task_patch`
- `experiment_state.next_round.experiment_strategy`
- `run_client_patch_experiment.patch_execution`（如果上一轮使用了客户端 proposal）
- `apply_client_code_patch.patch_execution`（如果上一轮直接改了 workspace 代码）
- memory trace / memory suggestions（当 `get_service_manifest` 暴露 memory tools 时）

## 决策规则

- 如果 `planner_actions` 非空，优先解释并执行第一个 action，除非用户明确要求改走其他路径。
- 如果 `failure_diagnostics.failed_count > 0`，先按 `category_counts` 和 `recommended_recovery` 看日志；不要盲目扩大搜索空间。
- 如果 `research_evidence_gate.recommended_action == "refresh_research"`，先查看 `research_evidence_gate.retrieval_recovery`，再重新调用 `research_task`；不要把空来源的假设当成论文证据。
- 如果可用 memory suggestion，先检查 provenance、artifact refs、known failures 和适用条件；不要把历史建议直接当成当前任务的已验证改动。
- 读取 `research_task` 结果时，同时检查 `deduplication_report`、`cache_summary`、`provider_quality_matrix`、`provider_coverage` 和 `retrieval_diagnostics.summary.provider_count`；如果 provider 覆盖不足或 unknown 来源过多，优先补检索而不是直接扩实验。
- 如果最近实验有目标 metric 且 accepted，先查看 `code_change_plan.next_experiment_plan` 的候选值、停止条件和 edit policy；若存在 `proposed_task_patch`，优先用它做单参数验证，否则再使用 `next_round.task_patch`。
- 如果 `experiment_state.loop_policy.decision == "stop"`，先处理 `reason_category` 和 `recommended_next_action`；尤其是 `reproduction_blocked` 时不要继续跑实验。
- 如果 `experiment_state.metric_stop_policy.decision == "stop"`，先处理 `stop_reason`；不要只因为存在 `next_round.task_patch` 就继续。
- 使用 `proposed_task_patch` 前先执行 `dry_run_validation.preflight_checks`，实验完成后按 `dry_run_validation.post_run_checks` 调用 `review_research_results` 并判断是否停止。
- 如果 `proposed_task_patch` 可接受且不需要客户端改代码，优先调用 `run_next_experiment_from_review`，让 MCP 自动选择 patch 并执行下一轮。
- 如果你要基于 GPT-5.5/Claude 的判断自行改一个 SEARCH REGION 参数，调用 `run_client_patch_experiment`，传入单参数 `change_proposal`，并检查返回的 `patch_execution.mode == "task_patch_only"`、`patch_execution.diff_preview` 和 `patch_execution.execution_guardrails`。
- 如果必须直接改 workspace 代码，调用 `apply_client_code_patch`，只传 workspace-relative unified diff；优先设置 `allowed_files` 和小型 `test_command`，并检查 `preflight`、`syntax_check`、`test_check`、`rollback`。
- `change_proposal.current_value` 必须来自最新 `experiment_state.current_code.search_region`；如果 MCP 返回 `stale_patch`，先重新 `review_research_results`，不要强行继续。
- 如果最近实验没有目标 metric，先检查 `current_code.search_region` 和日志，再缩小到可运行参数。
- 如果 `experiment_strategy.mode == "debug_failures"`，优先调用 `get_experiment_result` 或日志工具，不要启动大批量实验。
- 如果连续两轮没有改善，停止当前局部方向，重新调用 `research_task` 或人工修改假设。
- 如果一个 memory suggestion 与当前 evidence gate、dataset profile、metric direction 或 resource budget 冲突，优先相信当前 artifacts 和 review，而不是历史经验。
- 如果用户明确要求无人值守，调用 `run_ai_autoresearch`，并显式设置 `llm_provider`。

## 下一轮 MCP 调用

开始 proposal 前，如果 manifest 暴露 Research Memory 工具，先检索相似经验：

```json
{
  "name": "retrieve_research_memory",
  "arguments": {
    "store": ".demo_runs/research-memory/memory.jsonl",
    "query": "<paper/dataset/metric/failure/patch context>",
    "paper_id": "<optional arxiv id>",
    "dataset": "<optional dataset>",
    "limit": 5
  }
}
```

需要候选动作时，调用 `suggest_from_memory`，再用 `audit_memory_trace` 检查
card、artifact hash 和 claim boundary。只有确认当前证据、数据集、metric
方向和预算兼容后，才能进入下面的 guarded MCP execution。

常规下一轮：

```json
{
  "name": "run_next_experiment_from_review",
  "arguments": {
    "task_id": "<experiment_state.task_id>",
    "runtime_root": "<experiment_state.artifacts.runtime_root>",
    "workspace": "<experiment_state.artifacts.workspace>"
  }
}
```

需要手动改 task patch 时，改用 `run_hypothesis_experiment` 并传入调整后的
`experiment_state.planner_actions[0].arguments`。

客户端模型自行提出单参数改动时：

```json
{
  "name": "run_client_patch_experiment",
  "arguments": {
    "task_config": "/ABS/PATH/TO/runtime/tasks/my-task.json",
    "runtime_root": "/ABS/PATH/TO/runtime",
    "workspace": "/ABS/PATH/TO/runtime/workdir/my-task",
    "change_proposal": {
      "change_type": "hyperparam",
      "target": "DEPTH",
      "current_value": "1",
      "proposed_value": "2",
      "reason": "recent accepted runs suggest testing a slightly deeper model",
      "confidence": 0.72
    },
    "max_experiments": 1,
    "include_final_review": true
  }
}
```

客户端模型直接改 workspace 代码时：

```json
{
  "name": "apply_client_code_patch",
  "arguments": {
    "runtime_root": "/ABS/PATH/TO/runtime",
    "workspace": "/ABS/PATH/TO/runtime/workdir/my-task",
    "patch": "--- a/train.py\n+++ b/train.py\n@@ -12,1 +12,1 @@\n-DEPTH = 1\n+DEPTH = 2\n",
    "allowed_files": ["train.py"],
    "run_syntax_check": true,
    "test_command": ["/ABS/PATH/TO/python3", "-m", "py_compile", "train.py"],
    "task_id": "my-task",
    "include_post_patch_review": true,
    "initial_review": {"experiment_state": {"best_result": {"val": 1.0}}}
  }
}
```

无人值守下一轮：

```json
{
  "name": "run_ai_autoresearch",
  "arguments": {
    "task_config": "/ABS/PATH/TO/runtime/tasks/next-round.json",
    "runtime_root": "/ABS/PATH/TO/runtime",
    "llm_provider": "openai",
    "llm_model": "gpt-5.5",
    "max_experiments": 3,
    "experiment_duration": 300
  }
}
```

实验、patch 或 proof bundle 完成并经过 review 后，可以记录可复用经验：

```json
{
  "name": "record_research_memory",
  "arguments": {
    "store": ".demo_runs/research-memory/memory.jsonl",
    "release_manifest": "<release-proof-manifest.json>",
    "multi_round_report": "<multi-round-report.json>",
    "review_checklist": "<release-review-checklist.md>"
  }
}
```

## 停止条件

- 已达到用户指定 metric 阈值。
- 当前方向连续失败或没有目标 metric。
- 搜索空间只是在重复同类参数，没有新证据支持继续。
- 运行预算、时间预算或用户成本预算接近上限。
