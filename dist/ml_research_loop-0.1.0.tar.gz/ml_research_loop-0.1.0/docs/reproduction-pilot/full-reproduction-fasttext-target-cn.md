# Bag of Tricks for Efficient Text Classification 完整复现目标

## 目标

本目标用于把 bounded pilot 升级为完整复现轨道。当前 decision 为 `accepted_for_full_reproduction_track`，scope 为 `core_experiment_track`。

| 字段 | 内容 |
| --- | --- |
| 论文 | Bag of Tricks for Efficient Text Classification |
| 论文 ID | `arxiv:1607.01759` |
| 论文链接 | https://arxiv.org/abs/1607.01759 |
| 代码链接 | https://github.com/facebookresearch/fastText |
| 任务 | supervised text classification |
| 主指标 | `accuracy` |
| 数据轨道 | AG News or equivalent public text classification dataset |
| baseline 命令 | `fasttext supervised -input train.txt -output model` |
| evaluation 命令 | `fasttext test model.bin test.txt` |
| 资源画像 | `apple_silicon_m5_max_64gb_cpu_mps` |
| 本机硬件 | Apple M5 Max, 64GB unified memory |
| 可用训练画像 | `cpu_classical_ml`, `mps_accelerated_small_dl`, `single_machine_medium_batch_training` |
| 预计运行时间 | 30 分钟 |

## 完整复现定义

本阶段的“完整复现”指复现论文的一个核心实验轨道：数据准备、baseline 训练、评测、结果归档和人工复核必须闭环。它不是一次性复现所有表格，也不是官方 leaderboard 成绩。

## 自动提升定义

在 baseline 可信之后，客户端模型可以提出 patch 或超参改动；MCP 负责执行、评测、记录 diff 和回滚。只有在 held-out/test 指标优于本地 baseline 时，才能写入 `improvement-report.json`。

## P1 Harness 状态

当前 P1 已跑通本地 harness baseline：

```bash
python3 scripts/full_reproduction_run.py \
  --target-spec docs/reproduction-pilot/full-reproduction-target.json \
  --output-dir .demo_runs/full-reproduction-harness \
  --run-baseline \
  --json
```

该命令会生成：

- `dataset-provenance.json`
- `data/train.txt`
- `data/test.txt`
- `baseline-report.json`
- `evaluation-report.json`
- `client-handoff.json`
- `model.json`

当前 baseline 是 `python_fasttext_style_fallback`，用于验证数据准备、fastText supervised 格式、训练/评测解析和 artifact 边界。它不是官方 fastText binary 结果，也不是论文完整复现成绩。下一步 P2 才进入论文 baseline 对齐。

## P2 Baseline Alignment 状态

当前 P2 已跑通 baseline alignment：

```bash
python3 scripts/full_reproduction_run.py \
  --target-spec docs/reproduction-pilot/full-reproduction-target.json \
  --output-dir .demo_runs/full-reproduction-alignment \
  --align-baseline \
  --repeat-count 3 \
  --json
```

该命令会生成：

- `dataset-provenance.json`
- `data/ag-news-reference-slice.jsonl`
- `data/train.txt`
- `data/test.txt`
- `baseline-report.json`
- `evaluation-report.json`
- `baseline-reruns.json`
- `alignment-report.json`
- `client-handoff.json`
- `model.json`

当前 P2 的意义是证明：同一个 fastText-format reference slice 可以稳定复跑 baseline，并把论文目标、数据版本、训练命令、评测命令、本地结果和 claim gap 写入 artifact。它仍不是官方 fastText binary、不是完整 AG News 数据集，也不是论文完整复现成绩。下一步 P2+ 应替换为完整公开数据和官方/等价 fastText 训练路径。

## P2+ Full-data Alignment Gate 状态

当前 P2+ 已支持接入本地 AG News CSV，并做 full-data alignment gate：

```bash
python3 scripts/full_reproduction_run.py \
  --target-spec docs/reproduction-pilot/full-reproduction-target.json \
  --output-dir .demo_runs/full-reproduction-full-data \
  --align-full-data \
  --ag-news-train-csv /path/to/ag_news_csv/train.csv \
  --ag-news-test-csv /path/to/ag_news_csv/test.csv \
  --fasttext-binary /path/to/fasttext \
  --repeat-count 3 \
  --json
```

该命令会生成：

- `dataset-provenance.json`
- `data/ag-news-csv.jsonl`
- `data/train.txt`
- `data/test.txt`
- `baseline-report.json`
- `evaluation-report.json`
- `baseline-reruns.json`
- `fasttext-runtime-probe.json`
- `full-data-alignment-report.json`
- `client-handoff.json`
- `model.json`

P2+ 的新增价值是：把 AG News CSV 转换、fastText runtime 探测、论文目标值、tolerance、本地 fallback baseline 和 claim gap 放进同一份 report。当前 release gate 不默认联网下载完整 AG News，也不要求本机安装 fastText；如果传入的是小 fixture，report 会记录 `is_full_expected_size=false`，并继续阻断完整复现 claim。

当前 paper target 采用 fastText 官方 supervised models 页面中 AG News regular model 的 accuracy `0.924`，本地 tolerance 为 `0.02`。这个 target 只用于后续对齐判断；只有在完整公开数据、官方/等价 fastText 训练路径、训练日志和人工复核都归档后，才能升级 claim。

## P2++ Selected-binary Baseline 状态

当前 P2++ 已支持显式传入 fastText-compatible binary，执行训练和测试并归档日志：

```bash
python3 scripts/full_reproduction_run.py \
  --target-spec docs/reproduction-pilot/full-reproduction-target.json \
  --output-dir .demo_runs/full-reproduction-fasttext-baseline \
  --run-fasttext-baseline \
  --ag-news-train-csv /path/to/ag_news_csv/train.csv \
  --ag-news-test-csv /path/to/ag_news_csv/test.csv \
  --fasttext-binary /path/to/fasttext \
  --json
```

该命令会生成：

- `dataset-provenance.json`
- `data/train.txt`
- `data/test.txt`
- `fasttext-runtime-probe.json`
- `logs/fasttext-train.log`
- `logs/fasttext-test.log`
- `fasttext-baseline-report.json`
- `client-handoff.json`

`fasttext-baseline-report.json` 会记录实际 training/test command、return code、log 路径、`P@1`、paper target、tolerance、数据是否达到完整 AG News 行数，以及 claim gap。默认 release gate 使用 fake fastText-compatible binary 验证执行链路，因此只能证明“训练/测试/日志/解析链路可工作”，不能证明官方 fastText 成绩。真实完整复现必须使用完整 AG News CSV 和真实官方/等价 fastText runtime 重新运行。

## P2+++ 真实本地 fastText/AG News Baseline 状态

当前 P2+++ 已在本机用完整 AG News CSV 和官方 fastText binary 跑通一次真实 baseline：

```bash
.venv/bin/python scripts/full_reproduction_run.py \
  --target-spec docs/reproduction-pilot/full-reproduction-target.json \
  --output-dir .demo_runs/p2ppp-fasttext-real-baseline \
  --run-fasttext-baseline \
  --ag-news-train-csv .demo_runs/p2ppp-ag-news-current/train.csv \
  --ag-news-test-csv .demo_runs/p2ppp-ag-news-current/test.csv \
  --fasttext-binary .external/fastText/fasttext \
  --max-train-seconds 900 \
  --json
```

本次运行结果：

- 完整 AG News 行数：train `120000`，test `7600`
- fastText binary：本机编译的 `facebookresearch/fastText`，commit `1142dc4`
- baseline 训练参数：`-thread 1 -seed 0`，用于降低 fastText 多线程训练带来的复现波动
- test log：`N=7600`，`P@1=0.914`，`R@1=0.914`
- target tolerance：`0.924±0.02`
- 结论：本地真实 baseline 落入当前 target tolerance

证据文档见 `docs/evidence/fasttext-ag-news-real-baseline-20260513-cn.md`。该结果可以作为后续 P3 自动 patch / 超参搜索的可信 baseline，但仍不是官方 leaderboard score，也不是完整复现论文所有实验表格。

## P3 Client Patch Loop 状态

当前 P3 已在本机用完整 AG News CSV、官方 fastText binary 和 P2+++ baseline
report 跑通一次受控 client-proposed patch round：

```bash
.venv/bin/python scripts/full_reproduction_run.py \
  --target-spec docs/reproduction-pilot/full-reproduction-target.json \
  --output-dir .demo_runs/p3-fasttext-real-patch \
  --run-fasttext-patch-round \
  --ag-news-train-csv .demo_runs/p2ppp-ag-news-current/train.csv \
  --ag-news-test-csv .demo_runs/p2ppp-ag-news-current/test.csv \
  --fasttext-binary .external/fastText/fasttext \
  --baseline-report .demo_runs/p2ppp-fasttext-real-baseline/fasttext-baseline-report.json \
  --fasttext-proposal .demo_runs/p3-fasttext-real-patch/proposal-wordngrams-2.json \
  --max-train-seconds 900 \
  --json
```

本次 proposal 为 `-wordNgrams 2`，结果：

- baseline `P@1=0.914`
- patch 后 `P@1=0.916`
- delta `+0.002`
- `within_tolerance=true`
- `official_scores_claimed=false`

新增 artifacts：

- `fasttext-runtime-probe.json`
- `patch-proposal.json`
- `patch-diff.patch`
- `logs/fasttext-patch-train.log`
- `logs/fasttext-patch-test.log`
- `improvement-report.json`
- `client-handoff.json`

证据文档见 `docs/evidence/fasttext-ag-news-p3-patch-round-20260513-cn.md`。
该结果证明“客户端模型提出受限 proposal，MCP 执行并归档真实训练结果”的第一条
闭环已经跑通；它仍不是无人值守自动科研，也不是完整论文所有表格的复现。

## P4 Proof Bundle 状态

当前 P4 已将 P3 真实 patch round 打包为 human-reviewed proof bundle：

```bash
.venv/bin/python scripts/full_reproduction_run.py \
  --target-spec docs/reproduction-pilot/full-reproduction-target.json \
  --output-dir .demo_runs/p4-fasttext-real-proof \
  --write-fasttext-patch-proof-bundle \
  --patch-round-report .demo_runs/p3-fasttext-real-patch/improvement-report.json \
  --reviewer codex-local-review \
  --json
```

本次 proof bundle 结果：

- review status：`approved_with_limitations`
- artifact count：`10`
- `proof-manifest.json`
- `human-review-report.json`
- `artifact-index.json`
- `SHA256SUMS`
- `proof-summary.md`
- `official_scores_claimed=false`

证据文档见 `docs/evidence/fasttext-ag-news-p4-proof-bundle-20260514-cn.md`。
P4 的意义是把本地 patch loop 结果转为可复查、可 hash 核验、带声明边界的
proof artifact；它仍不代表官方 leaderboard 或论文全表格复现。

## P5 多轮 proposal 与 Release Proof Bundle 状态

当前 P5 已在同一 fastText AG News 轨道上跑通“多轮 proposal + 失败样例 +
best-so-far 回滚 + release proof 下载包”：

```bash
.venv/bin/python scripts/full_reproduction_run.py \
  --target-spec docs/reproduction-pilot/full-reproduction-target.json \
  --output-dir .demo_runs/p5-fasttext-real/multi-round \
  --run-fasttext-multi-proposal-loop \
  --ag-news-train-csv .demo_runs/p2ppp-ag-news-current/train.csv \
  --ag-news-test-csv .demo_runs/p2ppp-ag-news-current/test.csv \
  --fasttext-binary .external/fastText/fasttext \
  --baseline-report .demo_runs/p2ppp-fasttext-real-baseline/fasttext-baseline-report.json \
  --fasttext-proposals .demo_runs/p5-fasttext-real/proposals.json \
  --max-train-seconds 900 \
  --json
```

本次多轮结果：

- proposal count：`2`
- completed count：`1`
- failure count：`1`
- rollback events：`1`
- best metric：`P@1=0.916`
- best source：`round-001-p5-wordngrams-2`
- failed proposal：`p5-invalid-bucket`，原因是 `bucket` 不在 allowlist 内
- `official_scores_claimed=false`

随后将 P4 proof manifest 和 P5 multi-round report 打成 release proof bundle：

```bash
.venv/bin/python scripts/full_reproduction_run.py \
  --target-spec docs/reproduction-pilot/full-reproduction-target.json \
  --output-dir .demo_runs/p5-fasttext-real/release-proof \
  --write-fasttext-release-proof-bundle \
  --proof-manifest .demo_runs/p4-fasttext-real-proof/proof-manifest.json \
  --multi-round-report .demo_runs/p5-fasttext-real/multi-round/multi-round-report.json \
  --reviewer codex-local-review \
  --json
```

release proof 输出：

- `release-proof-manifest.json`
- `release-review-checklist.md`
- `release-proof-bundle.tar.gz`
- `release-proof-bundle.sha256`
- bundle sha256：`7e48e9d50934d476bcd57dfdd6925db4eb4cd646fec2f9f76624108be16bbf45`

证据文档见 `docs/evidence/fasttext-ag-news-p5-release-proof-20260514-cn.md`。
P5 的意义是把“多轮 proposal 有成功也有失败，失败不被隐藏，系统能回滚到最佳
已验证结果，并把证据打包给外部复核”这条产品能力跑通；它仍不是官方榜单、
完整论文全表格复现或任意自动科研能力。

## 必需 artifact

- `target-spec.json`
- `dataset-provenance.json`
- `baseline-report.json`
- `evaluation-report.json`
- `client-handoff.json`
- `patch-diff.patch`
- `improvement-report.json`
- `human-review-report.json`
- `proof-manifest.json`
- `multi-round-report.json`
- `release-proof-manifest.json`
- `release-proof-bundle.tar.gz`
- `release-proof-bundle.sha256`

## 当前 blockers

- 无

## 不能宣称

- `full_paper_all_tables`
- `official_benchmark_or_sota`
- `unattended_research_replacement`

所有输出必须保留 `official_scores_claimed=false`，除非后续真实跑过官方 scorer 或论文官方复现脚本并归档完整证据。
