---
name: ml-research-loop-reproduction
description: Use when reproducing a paper, checking reproduction readiness, creating rubric-based evaluations, or grading ML Research Loop artifacts
---

# ML Research Loop Reproduction

## Purpose

Use this skill for PaperBench-style lightweight reproduction inside ML Research Loop. The goal is to move from paper evidence to local required files, runnable commands, and a deterministic `grade_report`.

Canonical architecture: reproduction proof remains in runtime artifacts and proof archives. Research Memory Layer may retrieve prior reproduction experience, but it cannot replace required files, logs, rubric evidence, or human/client-model review.

## Flow

1. Gather evidence with `read_paper` for a known paper or `research_task` for a broader objective.
2. If memory tools are available, call `retrieve_research_memory` for prior reproduction cases with similar paper type, dataset, metric, missing files, failed commands, or rubric gaps. Treat them as hints only and use `audit_memory_trace` before relying on them.
3. Convert the target into a local `reproduction_spec` with workspace-relative `required_files`, a bounded command, and a rubric.
4. Run or reuse an experiment with `run_hypothesis_experiment`.
5. Review with `review_research_results`.
6. Inspect `experiment_state.reproduction.readiness`, `missing_files`, `invalid_required_files`, and `grade_report`.
7. For PaperBench run artifacts, use `prepare_paperbench_codex_review_bundle`
   to gather `paper.md`, `rubric.json`, run logs, grading metadata, and
   submission metadata into a Codex review packet.
8. After Codex/Claude reviews the packet against the rubric, persist the
   non-official audit with `write_paperbench_codex_review_report`.
9. For the fastText AG News full-reproduction track, first establish a trusted
   baseline with `run_fasttext_binary_baseline`, then let Codex/Claude propose a
   bounded training-argument change and execute it with `run_fasttext_patch_round`.
10. After a useful fastText patch round, call
   `write_fasttext_patch_round_proof_bundle` to produce
   `human-review-report.json`, `proof-manifest.json`, `artifact-index.json`, and
   hashed artifact evidence before treating the result as public proof.
11. When stronger release evidence is needed, call
    `run_fasttext_multi_proposal_loop` with several bounded proposals, including
    at least one failed or rejected proposal when available, then package the
    reviewed P4/P5 evidence with `write_fasttext_release_proof_bundle`.
12. When memory write tools are available, use `record_research_memory` to
    record the final reproduction
    readiness, proof manifest, missing-file blockers, rubric gaps, useful patch
    settings, and rejected proposals as memory cards.

## Required Checks

- `required_files` must be workspace-relative. Absolute paths and `..` escapes are invalid.
- Treat `invalid_required_files` as a hard blocker until the spec is fixed.
- Treat missing files as a reproduction readiness failure, not as a model-quality failure.
- A usable rubric has leaf tasks with clear requirements and weights.
- A `grade_report.score` is only meaningful after readiness is `ready` or the report explains why not.
- `write_paperbench_codex_review_report` records Codex-assisted rubric
  judgment only. It is not an official PaperBench score and should retain
  `official_scores_claimed=false`.
- `run_fasttext_patch_round` must consume an existing baseline report and an
  allowlisted proposal. Treat `improvement-report.json` and
  `client-handoff.json` as local reproducibility artifacts, not as full-paper or
  leaderboard proof.
- `write_fasttext_patch_round_proof_bundle` must keep
  `official_scores_claimed=false`; `proof-manifest.json` only proves the local
  patch round artifacts were reviewed and hashed.
- `run_fasttext_multi_proposal_loop` must preserve `multi-round-report.json`,
  failed proposal records, and `rollback_summary`; it proves loop behavior, not
  official SOTA.
- `write_fasttext_release_proof_bundle` must produce a downloadable
  `release-proof-bundle.tar.gz`, checksum, review checklist, and release
  manifest while keeping `official_scores_claimed=false`.
- Memory from similar papers can prioritize a checklist, but it cannot mark a
  reproduction as ready unless current required files, command, rubric, logs,
  and proof artifacts support that claim.

## Demo

Use `scripts/mcp_reproduction_demo.py --max-experiments 1 --experiment-duration 30 --json` for the deterministic local smoke test. It does not require Docker, GPU, network, or LLM credentials.

## Output

Report paper/source evidence, reproduction readiness status, missing or invalid files, rubric coverage, `grade_report.score`, fastText baseline/patch metrics when present, multi-round failure/rollback counts when present, release bundle path/checksum when present, and result artifact paths.
